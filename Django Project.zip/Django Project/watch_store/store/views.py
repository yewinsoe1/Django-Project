from django.shortcuts import render,redirect,get_object_or_404
import datetime
from django.contrib import messages
from store.models import PostModel,CategoryModel
from django.contrib.auth.decorators import login_required,permission_required
# Create your views here.
#post list

def post_list(request):
    posts = PostModel.objects.all()
    return render(request, 'postlist.html', {"posts": posts})




#create posts
#@login_required(login_url='login')
@permission_required('store.add_postmodel', login_url='login')
def post_create(request):
    if request.method == "GET":
        return render(request, 'postCreate.html')
    
    if request.method == "POST":
        post = PostModel.objects.create(
            title = request.POST.get('title'),
            body = request.POST.get('body'),
            create_at = request.POST.get('created'),
        )

        post.save()
        return redirect('/store/')
    
# Detail posts
#@login_required(login_url='login')
@permission_required('store.add_postmodel', login_url='login')
def post_detail(request, post_id):
    posts = PostModel.objects.get(id=post_id)
    return render(request, 'postDetail.html',{"posts":posts})


# Update Posts
def post_update(request, post_id):
    post = get_object_or_404(PostModel, id=post_id)
    if request.method == "GET":
        post.created_at = post.created_at.strftime('%Y-%m-%dT%H:%M')
        return render(request, 'postUpdate.html', {"post":post})
    
    if request.method == "POST":
        post = get_object_or_404(PostModel, id=post_id)
        post.title =request.POST.get('title')
        post.body = request.POST.get('body')
        post.created_at = request.POST.get('created')
        post.save()
        return redirect('/store/')
    
#delete posts

def post_delete(request, post_id):
    posts = PostModel.objects.filter(id=post_id)
    posts.delete()
    messages.success(request, "The post has been creat successfully,")
    return redirect('/store/')


#login posts

from django.contrib.auth import authenticate, login, logout
def login_view(request):
    if request.method == "GET":
        return render(request,'login.html')
    if request.method =="POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(username = username, password = password)
        if user is not None:
            login(request, user)
            messages.success(request, "You are now logged in as "+ username)
            return redirect('/store/')
        else:
            messages.error(request, "Username or PAssword is incorrect !")
            return render(request,'login.html')
        

def logout_view(request):
    logout(request)
    return redirect('/login/')


#category create

@permission_required('store.add_postmodel', login_url='login')
def post_create(request):
    if request.method == "GET":
        category = CategoryModel.objects.all()
        return render(request, 'postCreate.html', {"category":category})
    
    if request.method == "POST":
        post = PostModel.objects.create(
            title = request.POST.get('title'),
            body = request.POST.get('body'),
            category_id = request.POST.get('category'),
            image = request.FILES.get('image'),
            author_id = request.user.id,
            #create_at = datetime.now()
        )
        

        post.save()
        messages.success(request, "The Post has been vreated successfully.")
        return redirect('/store/')