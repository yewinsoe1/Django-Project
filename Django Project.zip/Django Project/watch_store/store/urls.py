from django.contrib import admin
from django.urls import path,include
from.import views



urlpatterns =   [
    path('', views.post_list, name='post_list'),
     path('create/', views.post_create, name='post_create'),
     path('detail/<int:post_id>/', views.post_detail),
     path('update/<int:post_id>/', views.post_update),
     path('delete/<int:post_id>/', views.post_delete),


]
